//
//  CirclePayer.swift
//  Swift_CirclePayer
//
//  Created by LSH on 16/2/15.
//  Copyright © 2016年 Practice. All rights reserved.
//

/*
  QQ:1311054081  邮箱:zhangkangreadstone@163.com
 刚入门的小菜鸟,有什么缺点或不足,欢迎大家指正,
*/

import UIKit
import KFSwiftImageLoader

/*
注意:此方法使用前 需要KFSwiftImageLoader第三方来异步加载图片
通过Cocoapods导入.......
*/

enum PageContrlPointType
{
    case CenterDown  ///默认
    case RightDown////右下
}

typealias TapFuncBlock = (NSInteger)->()

class CirclePayer: UIView ,UIScrollViewDelegate{
    
    var scrollView :UIScrollView?
    var page:CGFloat = 0
    var images:NSMutableArray?
    var pageControl:CustomeImagsPageControl?
    ///闭包函数 把点击的页码传过去
    var tapFunc:TapFuncBlock?
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
  
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.yellowColor()
    }
    
    ////对传进来的图片数组进行处理,把最后一张图片插到最前面,把最前面一张加到最后面
    func makeDownImagesAndSetTypes(images:NSMutableArray,pageControlOriganXType:PageContrlPointType,pageSelectedImgName:String?,pageUnselectedImgName:String?)
    {
        self.images = images
        let firstImage = self.images?.firstObject
        let lastImage = self.images?.lastObject
        self.images?.insertObject(lastImage!, atIndex: 0)
        self.images?.addObject(firstImage!)
        addAScrollviewFroPlayer()
        addImgViewOnScrollView()
        addPageControl(pageControlOriganXType,selectedImg: pageSelectedImgName,unSelectedImg: pageUnselectedImgName)
        addTimerForPayer()
    }
    
    ////在添加的ScrollView上添加ImageView
    func addImgViewOnScrollView()
    {
        let count = (self.images?.count)!-1
        for index in 0...count
        {
            let imgView = UIImageView(frame: CGRectMake(CGFloat(index)*self.frame.width, 0, self.frame.width, self.frame.height))
            if self.images![index].isKindOfClass(UIImage){
                imgView.image = self.images![index] as? UIImage
            }else{
                imgView.loadImageFromURL(NSURL(string: (self.images![index] as? String)!)!)
            }
            imgView.backgroundColor = UIColor.cyanColor()
            scrollView?.addSubview(imgView)
        }
    }
    
    ///添加PageControl
    func addPageControl(pageControlLocationType:PageContrlPointType,selectedImg:String?,unSelectedImg:String?)
    {
        var origanX:CGFloat = 0
        switch pageControlLocationType{
        case PageContrlPointType.RightDown:////右下
            origanX = self.frame.width*2/3.0
        default :////默认位置
            origanX = self.frame.width/3.0
            break;
        }
        pageControl = CustomeImagsPageControl(frame: CGRectMake(origanX,self.frame.height-40,self.frame.width/3.0, 30))
        pageControl?.addTarget(self, action: Selector("pageSelected"), forControlEvents: UIControlEvents.ValueChanged)
        if ((selectedImg?.isEmpty) == false) {
            pageControl?.selectedImg = UIImage(named: selectedImg!)
            pageControl?.unSelectedImg = UIImage(named: unSelectedImg!)
        }
        pageControl?.currentPage = 0
        self.addSubview(pageControl!)
        pageControl!.pageIndicatorTintColor = UIColor.cyanColor()
        pageControl!.numberOfPages = (self.images?.count)!-2
       
    }
   
    ///pageControl事件
    func pageSelected()
    {
        let page = pageControl?.currentPage
        scrollView?.scrollRectToVisible(CGRectMake(CGFloat(page! + 1)*self.frame.width, 0, self.frame.width, self.frame.height), animated: true)
    }
    
    ///添加UIScrollView
    func addAScrollviewFroPlayer()
    {
        scrollView = UIScrollView(frame: CGRectMake(0,0,self.frame.width, self.frame.height))
        let w = self.frame.width
        scrollView?.contentSize = CGSizeMake(w * CGFloat((self.images?.count)!), self.frame.size.height )
        scrollView?.delegate = self
        scrollView?.showsHorizontalScrollIndicator = false
        scrollView?.pagingEnabled = true
        
        let tap = UITapGestureRecognizer(target: self, action: Selector("tapImg"))
        scrollView?.addGestureRecognizer(tap)
        
        self.addSubview(scrollView!)
    }
    
    ////点击手势
    func tapImg()
    {
       if self.tapFunc == nil {///处理未定义闭包函数的情况
        return
       }else{
          self.tapFunc!((pageControl?.currentPage)!)
       }
    }
    
    ////添加计时器自动轮播
    func addTimerForPayer()
    {
        let timer = NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: Selector("play"), userInfo: nil, repeats: true)
        NSRunLoop.mainRunLoop().addTimer(timer, forMode: NSRunLoopCommonModes)
    }
    
    func play()
    {
        let page = pageControl?.currentPage
        scrollView?.scrollRectToVisible(CGRectMake(CGFloat(page! + 2)*self.frame.width, 0, self.frame.width, self.frame.height), animated: true)
    }
    
    func scrollViewDidScroll(scrollView: UIScrollView)
    {
        let over = scrollView.contentOffset.x % self.frame.width
        let page = scrollView.contentOffset.x / self.frame.width
        let maxPage = scrollView.contentSize.width/self.frame.width
        if page < 0.5 {
            pageControl?.currentPage = Int(maxPage)
        }else
            if page > CGFloat((self.images?.count)! - 2)+0.5
            {
                pageControl?.currentPage = 0
            }else{
                
                pageControl?.currentPage = over > self.frame.width/2.0 ? Int(page) : Int(page)-1
        }

    }
    
    /*
     scrollViewWillBeginDragging此方法的意义:
    当手指快速拖动的时候,会有一种情况:拖动①位置的D后立即拖动②位置的A会导致:②位置的A尚未被①位置的A替换掉(scrollViewDidEndDecelerating方法尚未走就被再次拖动),形成scrollView回弹效果,影响无限循环的流畅效果
    所以,我们在将要开始拖动的时候判断一下,是否拖动的是②位置的A如果是就先用①位置的A替换掉再进行拖动,就能很流畅了
    */
    func scrollViewWillBeginDragging(scrollView: UIScrollView)
    {
        if scrollView.contentOffset.x >  CGFloat(self.images!.count-2)*self.frame.width || scrollView.contentOffset.x < self.frame.width
        {
            controlScrollViewContentOffSet(scrollView)
        }
    }
    
    
    ///此方法拖动时走而scrollRectToVisible调用时不会走
    func scrollViewDidEndDecelerating(scrollView: UIScrollView)
    {
         controlScrollViewContentOffSet(scrollView)
    }
    
    ////此方法scrollRectToVisible调用时会走,而拖动时不走
    func scrollViewDidEndScrollingAnimation(scrollView: UIScrollView)
    {
        controlScrollViewContentOffSet(scrollView)
    }
    
    func controlScrollViewContentOffSet(scrollView:UIScrollView)
    {
        ///到已经结束减速的时候
        /*
        原理如下图 在A/B/C/D的前面插入一个D,后面再接上一个A
        结束减速的时候判断一下 当显示的②位置上的A时就立即用scrollView.contentOffset
        方法将①位置上的A偏移到当前屏幕上,这个过程很快人眼分辨不出
        同样的道理当滑动到②位置上的D时就将scrollView的偏移量设置成①位置的偏移量就行了
        ________________________________________________
        |       |       |       |       |       |       |
            ②      ①                      ①       ②
        _________________________________________________
        |       |       |       |       |       |       |
        |       |       |       |       |       |       |
        |   D   |   A   |   B   |   C   |   D   |   A   |
        |       |       |       |       |       |       |
        |_______|_______|_______|_______|_______|_______|
        */
        
        if scrollView.contentOffset.x < self.frame.width
        {
            scrollView.contentOffset = CGPointMake(CGFloat(self.images!.count-2)*self.frame.width, 0)
        }
        if scrollView.contentOffset.x > CGFloat((self.images?.count)!-2)*self.frame.width
        {
            scrollView.contentOffset = CGPointMake(self.frame.width, 0)
        }
    
    }
    
}

