//
//  ViewController.swift
//  CircleImagePlayer
//
//  Created by LSH on 16/2/16.
//  Copyright © 2016年 Practice. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        ///本地图片轮播
        let imgsArray:NSMutableArray = NSMutableArray()
        for index in 1...4{
            let img = UIImage(named: NSString(format: "%d.jpg", index) as String)
            imgsArray.addObject(img!)
        }
        let player = CirclePayer(frame: CGRectMake(0,0,self.view.frame.width,self.view.frame.width/1.5))
        player.makeDownImagesAndSetTypes(imgsArray, pageControlOriganXType:PageContrlPointType.CenterDown,pageSelectedImgName: "selected",pageUnselectedImgName: "unselected")
        self.view.addSubview(player)
        
        
        
        
        //网络图片轮播
        let url0 = "http://c.hiphotos.baidu.com/image/w%3D400/sign=c2318ff84334970a4773112fa5c8d1c0/b7fd5266d0160924c1fae5ccd60735fae7cd340d.jpg"
        let url1 =   "https://ss0.baidu.com/-Po3dSag_xI4khGko9WTAnF6hhy/super/whfpf%3D425%2C260%2C50/sign=a41eb338dd33c895a62bcb3bb72e47c2/5fdf8db1cb134954a2192ccb524e9258d1094a1e.jpg"
        let url2 = "https://ss2.baidu.com/-vo3dSag_xI4khGko9WTAnF6hhy/super/whfpf%3D425%2C260%2C50/sign=a4b3d7085dee3d6d2293d48b252b5910/0e2442a7d933c89524cd5cd4d51373f0830200ea.jpg"

        let urls = NSMutableArray(objects: url0,url1,url2)
        
        let player0 = CirclePayer(frame:  CGRectMake(0,self.view.frame.width/1.5+20,self.view.frame.width,self.view.frame.width/1.5))
        player0.makeDownImagesAndSetTypes(urls, pageControlOriganXType: PageContrlPointType.RightDown,pageSelectedImgName: nil,pageUnselectedImgName: nil)
        player0.tapFunc = {
            (param:NSInteger) -> () in
            print("我已经点击了\(param)页")
        }
        self.view.addSubview(player0)

        
    
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

