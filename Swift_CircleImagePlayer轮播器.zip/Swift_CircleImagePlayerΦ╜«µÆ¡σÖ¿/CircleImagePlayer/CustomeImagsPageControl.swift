
//
//  CustomeImagsPageControl.swift
//  CircleImagePlayer
//
//  Created by LSH on 16/2/23.
//  Copyright © 2016年 Practice. All rights reserved.
//

import UIKit

class CustomeImagsPageControl: UIPageControl {

    var selectedImg:UIImage?
    var unSelectedImg:UIImage?
    required  init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    override init(frame: CGRect) {
    super.init(frame: frame)
    }

    ///重写currentPage的setter和getter方法
    override var currentPage:Int{
        set{
         super.currentPage = newValue
            updatePointImg()
       }
        get{
          return super.currentPage
       }
    }
    override func endTrackingWithTouch(touch: UITouch?, withEvent event: UIEvent?) {
        super.endTrackingWithTouch(touch, withEvent: event)
        updatePointImg()
    }
    
    func updatePointImg(){
        if selectedImg != nil || unSelectedImg != nil
        {
        let arr = self.subviews
            if arr.count > 0{
            let num = arr.count-1
            for index in 0 ... num{
            let dot = arr[index] as UIView
                var dotView = dot.viewWithTag(111) as? UIImageView
                if dotView == nil{
                    dotView = UIImageView(frame: CGRectMake(0, 0, dot.frame.width, dot.frame.height))
                    dotView!.layer.cornerRadius = dot.frame.size.width/2.0;
                    dotView!.clipsToBounds = true;
                    dotView!.tag = 111;
                    dot.addSubview(dotView!)
                }
                dotView!.image = self.currentPage == index ? self.selectedImg : self.unSelectedImg
            }
        }
        }
    }

}
